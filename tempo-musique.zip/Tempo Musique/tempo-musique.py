"""
Tempo Musique — relie l'application Deezer de Windows à Tempo.

Deezer n'autorise plus les applications tierces à lire des titres complets.
Ce petit programme contourne le problème proprement : c'est l'appli Deezer
(avec ton compte Premium) qui joue la musique en entier, et Tempo sert de
télécommande. Il lit le titre en cours grâce aux contrôles multimédias de
Windows (ceux qui apparaissent quand on appuie sur une touche de volume) et
les met à disposition de Tempo, uniquement sur ce PC : http://127.0.0.1:8765

Prérequis : Windows 10 ou 11 et Python 3.9 ou plus récent.
Le fichier « Lancer Tempo Musique.bat » installe ce qu'il faut et le démarre.
"""
import argparse
import asyncio
import datetime as dt
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

try:
    from winrt.windows.media.control import (
        GlobalSystemMediaTransportControlsSessionManager as Manager,
        GlobalSystemMediaTransportControlsSessionPlaybackStatus as Status,
    )
    from winrt.windows.storage.streams import Buffer, DataReader, InputStreamOptions
except ImportError:
    if "--silencieux" in sys.argv:
        sys.exit(1)
    print("Il manque des modules. Lance plutôt « Installer Tempo Musique.bat », qui les installe.")
    input("Appuie sur Entrée pour fermer…")
    sys.exit(1)

PORT = 8765
VERSION = 2

# Origines autorisées à interroger le programme : la page Tempo ouverte depuis un fichier
# (origine « null ») et les pages servies en local. Ajoute ton site avec --origine.
ALLOWED = {"null", "https://olzog.github.io"}
ALLOWED_PREFIXES = ("http://localhost", "http://127.0.0.1")

LOOP = asyncio.new_event_loop()
threading.Thread(target=LOOP.run_forever, daemon=True).start()


def run(coro, timeout=6):
    return asyncio.run_coroutine_threadsafe(coro, LOOP).result(timeout)


STATE = {"manager": None, "art": None, "art_key": None}


def seconds(v):
    """TimeSpan Windows -> secondes (timedelta selon la version de pywinrt, sinon ticks de 100 ns)."""
    if v is None:
        return 0.0
    if isinstance(v, dt.timedelta):
        return v.total_seconds()
    try:
        return float(v.duration) / 10_000_000
    except AttributeError:
        return float(v) / 10_000_000


async def manager():
    if STATE["manager"] is None:
        STATE["manager"] = await Manager.request_async()
    return STATE["manager"]


async def session():
    m = await manager()
    sessions = list(m.get_sessions())
    deezer = [s for s in sessions if "deezer" in (s.source_app_user_model_id or "").lower()]
    return deezer[0] if deezer else m.get_current_session()


async def read_thumbnail(ref):
    if ref is None:
        return None
    stream = await ref.open_read_async()
    size = int(stream.size)
    if not size:
        return None
    buf = await stream.read_async(Buffer(size), size, InputStreamOptions.READ_AHEAD)
    try:
        data = bytes(buf)
    except TypeError:
        arr = bytearray(buf.length)
        DataReader.from_buffer(buf).read_bytes(arr)
        data = bytes(arr)
    return (stream.content_type or "image/jpeg", data)


async def now_playing():
    s = await session()
    if s is None:
        return {"ok": True, "active": False}
    props = await s.try_get_media_properties_async()
    pb = s.get_playback_info()
    tl = s.get_timeline_properties()
    status = pb.playback_status
    state = "playing" if status == Status.PLAYING else "paused" if status == Status.PAUSED else "stopped"
    start, end = seconds(tl.start_time), seconds(tl.end_time)
    pos = seconds(tl.position) - start
    duration = max(0.0, end - start)
    # Windows donne la position à l'instant de la dernière mise à jour : on la projette à maintenant.
    if state == "playing" and tl.last_updated_time:
        try:
            pos += (dt.datetime.now(dt.timezone.utc) - tl.last_updated_time).total_seconds()
        except TypeError:
            pass
    if duration:
        pos = min(max(pos, 0.0), duration)
    key = f"{props.title}|{props.artist}|{props.album_title}"
    if key != STATE["art_key"]:
        STATE["art_key"] = key
        try:
            STATE["art"] = await read_thumbnail(props.thumbnail)
        except Exception:
            STATE["art"] = None
    c = pb.controls
    return {
        "ok": True,
        "active": True,
        "app": s.source_app_user_model_id or "",
        "isDeezer": "deezer" in (s.source_app_user_model_id or "").lower(),
        "title": props.title or "",
        "artist": props.artist or "",
        "album": props.album_title or "",
        "state": state,
        "position": round(pos, 2),
        "duration": round(duration, 2),
        "canSeek": bool(c.is_playback_position_enabled),
        "canNext": bool(c.is_next_enabled),
        "canPrev": bool(c.is_previous_enabled),
        "hasArt": STATE["art"] is not None,
        "key": key,
    }


async def command(action, pos=None):
    s = await session()
    if s is None:
        return False
    if action == "toggle":
        return await s.try_toggle_play_pause_async()
    if action == "play":
        return await s.try_play_async()
    if action == "pause":
        return await s.try_pause_async()
    if action == "next":
        return await s.try_skip_next_async()
    if action == "prev":
        return await s.try_skip_previous_async()
    if action == "seek" and pos is not None:
        start = seconds(s.get_timeline_properties().start_time)
        return await s.try_change_playback_position_async(int((float(pos) + start) * 10_000_000))
    return False


class Handler(BaseHTTPRequestHandler):
    def allowed(self):
        origin = self.headers.get("Origin")
        return origin is None or origin in ALLOWED or origin.startswith(ALLOWED_PREFIXES)

    def head(self, code=200, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        origin = self.headers.get("Origin")
        if origin and self.allowed():
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Vary", "Origin")
        self.end_headers()

    def send_json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.head(code)
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        if self.allowed():
            self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin") or "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "*")
            self.send_header("Access-Control-Allow-Private-Network", "true")
        self.end_headers()

    def do_GET(self):
        if not self.allowed():
            return self.send_json({"ok": False, "error": "origine refusée"}, 403)
        path = urlparse(self.path).path
        try:
            if path == "/ping":
                return self.send_json({"ok": True, "name": "tempo-musique", "version": VERSION})
            if path == "/now":
                return self.send_json(run(now_playing()))
            if path == "/art":
                art = STATE["art"]
                if not art:
                    return self.send_json({"ok": False}, 404)
                self.head(200, art[0])
                return self.wfile.write(art[1])
        except Exception as e:  # session fermée, appli quittée…
            return self.send_json({"ok": True, "active": False, "error": str(e)})
        self.send_json({"ok": False, "error": "inconnu"}, 404)

    def do_POST(self):
        if not self.allowed():
            return self.send_json({"ok": False, "error": "origine refusée"}, 403)
        url = urlparse(self.path)
        if url.path != "/cmd":
            return self.send_json({"ok": False}, 404)
        q = parse_qs(url.query)
        try:
            ok = run(command(q.get("a", [""])[0], q.get("pos", [None])[0]))
            self.send_json({"ok": bool(ok)})
        except Exception as e:
            self.send_json({"ok": False, "error": str(e)})

    def log_message(self, *args):
        pass


def main():
    ap = argparse.ArgumentParser(description="Relie l'appli Deezer de Windows à Tempo.")
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--origine", action="append", default=[], help="Autorise une adresse de site supplémentaire (ex. https://moi.github.io)")
    ap.add_argument("--silencieux", action="store_true", help="Tourne en arrière-plan, sans fenêtre (utilisé par le bouton de Tempo)")
    args = ap.parse_args()
    ALLOWED.update(o.rstrip("/") for o in args.origine)
    try:
        server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError:
        # Déjà lancé (le port est pris) : rien à faire.
        if not args.silencieux:
            print("Tempo Musique tourne déjà sur ce PC.")
        return
    if args.silencieux:
        server.serve_forever()
        return
    print("Tempo Musique est prêt.")
    print(f"  Adresse locale : http://127.0.0.1:{args.port}")
    print("  Lance un titre dans l'appli Deezer : il s'affiche dans Tempo.")
    print("  Laisse cette fenêtre ouverte (tu peux la réduire). Ctrl+C pour arrêter.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Arrêt.")


if __name__ == "__main__":
    main()
