@echo off
chcp 65001 >nul
title Désinstallation de Tempo Musique
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*tempo-musique.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>nul
reg delete "HKCU\Software\Classes\tempo-musique" /f >nul 2>nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v TempoMusique /f >nul 2>nul
rmdir /s /q "%LOCALAPPDATA%\TempoMusique" 2>nul
echo Tempo Musique est désinstallé.
pause
