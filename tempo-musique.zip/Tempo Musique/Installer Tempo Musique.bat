@echo off
chcp 65001 >nul
title Installation de Tempo Musique
echo.
echo  Installation de Tempo Musique
echo  -----------------------------
set "DEST=%LOCALAPPDATA%\TempoMusique"

where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% --version >nul 2>nul
if errorlevel 1 (
  echo  Python n'est pas installé. Installe Python 3.12 depuis le Microsoft Store,
  echo  puis relance ce fichier.
  start "" "ms-windows-store://pdp/?productid=9NCVDN91XZQP"
  pause
  exit /b
)

echo  1/4 Arrêt d'une version déjà lancée...
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*tempo-musique.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>nul

echo  2/4 Copie du programme...
if not exist "%DEST%" mkdir "%DEST%"
copy /y "%~dp0tempo-musique.py" "%DEST%\tempo-musique.py" >nul

echo  3/4 Installation des modules Windows (une minute la première fois)...
%PY% -m pip install --quiet --disable-pip-version-check --upgrade winrt-runtime winrt-Windows.Foundation winrt-Windows.Foundation.Collections winrt-Windows.Media.Control winrt-Windows.Storage.Streams
for /f "delims=" %%i in ('%PY% -c "import sys; print(sys.executable)"') do set "PYEXE=%%i"

> "%DEST%\lancer.vbs" echo Set sh = CreateObject("WScript.Shell")
>> "%DEST%\lancer.vbs" echo sh.Run """%PYEXE%"" ""%DEST%\tempo-musique.py"" --silencieux", 0, False

echo  4/4 Création du raccourci « tempo-musique:// » utilisé par Tempo...
reg add "HKCU\Software\Classes\tempo-musique" /ve /d "URL:Tempo Musique" /f >nul
reg add "HKCU\Software\Classes\tempo-musique" /v "URL Protocol" /d "" /f >nul
reg add "HKCU\Software\Classes\tempo-musique\shell\open\command" /ve /d "wscript.exe \"%DEST%\lancer.vbs\"" /f >nul

echo.
choice /c ON /m " Démarrer Tempo Musique automatiquement avec Windows "
if errorlevel 2 (
  reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v TempoMusique /f >nul 2>nul
) else (
  reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v TempoMusique /d "wscript.exe \"%DEST%\lancer.vbs\"" /f >nul
)

wscript.exe "%DEST%\lancer.vbs"
echo.
echo  C'est prêt. Tempo Musique tourne en arrière-plan, sans fenêtre.
echo  Dans Tempo, le bouton « Démarrer Tempo Musique » le relance si besoin.
echo  Pour une mise à jour : relance simplement ce fichier.
echo.
pause
